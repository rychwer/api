package main

import "fmt"

// func nomefuncao(parametro tipo, parametro tipo) retorno
// func nomefuncao(parametro, parametro tipo) retorno
// func nomefuncao(parametro, parametro tipo) (tiporetorno1, tiporetorno2)
// _(underline) = ignora valores de retornos multiplos

func main() {
	var f = func() {
		fmt.Println("teste funcao")
	}

	f()

}
