package main

import "fmt"

func main() {
	var variavel1 string = "variavel 1"
	fmt.Println(variavel1)

	variavel2 := "variavel 2"
	fmt.Println(variavel2)

	var (
		variavel3 string = "ab"
		variavel4 string = "cd"
	)
	fmt.Println(variavel3, variavel4)

	variavel5, variavel6 := "ab", "cd"
	fmt.Println(variavel5, variavel6)

	const contrante1 string = "ab"
	fmt.Println(contrante1)

	variavel5, variavel6 = variavel6, variavel5

	fmt.Println(variavel5, variavel6)
}
