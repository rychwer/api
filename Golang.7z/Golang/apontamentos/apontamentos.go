//não é possivel fazer operações com tipos diferentes

//atribuição
// (=) sem inferencia de tipo
// (:=) com inferencia de tipo

// só tem pos increment
// não tem ternario

//___________________________________________________________

//struct seria quase igual a classe
//struct = coleção de campos
//type nomeDoTipo struct {}
// var usu nomeDoTipo
// usu.nome = "valor"
//usu2 := nomeDoTipo{valor1, valor2}
//usu3 := nomeDoTipo{nomeDaVariavel: valor}

//___________________________________________________________

// Ponteiro é uma referência de memoria
// (*) determina um ponteiro
// (&) captura o endereço de memoria
// var ponteiro *int = &variavel
// fmt.Println(*ponteiro) = converte para o valor

//___________________________________________________________

//Array
//var array1[tamanho] tipo
//array2 := [tamanho]tipo{valor1, valor2}
//array3 := [...]int{valor1, valor2}

//Slice
//slice := []int
//slice = append(slice, 18)
//slice2 := array2[1(inclusivo):3(exclusivo)]
//slice funciona como um ponteiro

//Map
//usuario := map[tipochave]tipovalor { "chave" : "valor" }
//usuario[chave]
//delete(map, nomeChave)
//map[chave] = map[tipochave] tipovalor {valorchave: valor}
//

//conficionais - estrutura de controle
// as chaves são obrigatorias
// (;) pode ser utilizado no if init para separar a atribuição da condição
// if init a variavel é limitada no escopo do if
//switch variavel { case 1: resultado }
//switch { case expressão }
//fallthrough = joga para o caso seguinte sem verificar a expressão
//go só possui for para loop
//for expressão { time.Sleep(time.Second) }
//for variavel := 0; variavel < 10; variavel++ { }
//for indice, valor := range array {  }
//for _, valor := range array {  }

//Funções
//func nomefuncao (p1, p2 tipo) (nomer1 tipo, nomer2 tipo) {} retorno nomeado
//func nomefuncao (variavel ...tipo) {} varargs(slice)
//defer adia a execução de uma função
//defer executa antes do return
//panic = throw, panic chama todas as funções com defer
//recover = exception handler, if r := recover(); r != nil {}
//método = func (variavel tipoStruct) nomeMetodo() retorno {}
//método = func (variavel *tipoStruct) nomeMetodo() retorno {} = para alterar um valor de dentro do struct
//type nome interface { metodo() tipo } = cria uma interface
//implementação da interface é implicita
//func (variavel tipoInterface) nomeMetodoInterface() retorno {}