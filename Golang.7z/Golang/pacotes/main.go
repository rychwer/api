package main

import (
	"fmt"

	"modulo/auxiliar"
)

func main() {
	fmt.Println("Oi!")
	auxiliar.Escrever()
}
