package main

import "fmt"

func main() {

	//int 8, 16, 32, 64
	var numero int16 = 100
	fmt.Println(numero)

	//uint = int sem sinal
	// rune = int32, alias
	// byte = int8

	//float32, float64

	//string = caracteres
	//go não tem char
	//char é com aspas simples, mas sera reduzido para int

	//todo tipo de dado tem um valor para erro é nil

	//boolean = bool, valor zero é false

	//erro = error, valor zero é nil
	// para criar um erro = errors.New("valor"), pacote do Go

}
