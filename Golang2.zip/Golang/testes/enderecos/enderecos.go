package enderecos

import "strings"

func TipoEndereco(endereco string) string {
	tiposValidos := []string{"rua", "avenida", "estrada", "rodovia"}
	endereco = strings.ToLower(endereco)

	primeiraPalavraEndereco := strings.Split(endereco, " ")[0]

	enderecoTipoValido := false

	for _, tipo := range tiposValidos {

		if primeiraPalavraEndereco == tipo {
			enderecoTipoValido = true
		}

	}

	if enderecoTipoValido {
		return strings.Title(primeiraPalavraEndereco)
	}

	return "Tipo Invalido"

}
