package enderecos

import "testing"

type cenarioTeste struct {
	enderecoInserido string
	retornoEsperado  string
}

func TestTipoEndereco(t *testing.T) {

	cenariosTeste := []cenarioTeste{
		{"Rua ABC", "Rua"},
		{"Avenida Avenida", "Avenida"},
		{"Estrada 123", "Estrada"},
		{"Praça 123", "Tipo Invalido"},
	}

	for _, cenario := range cenariosTeste {

		tipoEnderecoRecebido := TipoEndereco(cenario.enderecoInserido)
		if tipoEnderecoRecebido != cenario.retornoEsperado {
			t.Error("Deu ruim!")

		}

	}
}
