package main

import (
	"fmt"
	"testes/enderecos"
)

func main() {
	tipoEndereco := enderecos.TipoEndereco("Avenida Paulista")
	fmt.Println(tipoEndereco)
}
