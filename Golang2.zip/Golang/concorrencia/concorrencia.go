//Paralelismo != concorrencia
// Paralelismo = Duas tarefas executadas ao mesmo tempo (cada nucleo do PC)

// Concorrente = Não necessariamente estão executando ao mesmo / podem ser executadas em paralelismo
// Revezamento de processamento

//goroutine = função ou metodo -> go
// não espera terminar a execução da funcção para iniciar as demais instruções
//_____________________________________________________________________

//wait group
//var waitGroup sync.WaitGroup
//waitGroup.Add(quantidade)
// go func() { funcao() waitGroup.Done() }
// waitGroup.Wait()
//____________________________________________________________________

//Canais
//Canal de comunicação -> envia e recebe dados -> usa para sincronizar goroutines
// canal := make (chan tipoDado)
//go funcao(paramentro, canal)
//canal <- parametro
//mensagem := <-canal

//deadlock -> não existe mais ninguém enviando dado para o canal
// mas o canas ainda está esperando um dado
// só consegue identificar em tempo de execução
//é possivel saber se um canal está aberto ou fechado
//close(canal)
//mensagem, aberto(bool) := <-canal
//for mensagem := range canal {}

//Canais Buffer -> só bloqueia quando atinge a capacidade maxima
//canal := make (chan tipoDado, buffer)

//Select - tirar dependencia entre os canais
// select { case nome := <-canal }
//___________________________________________________________________

//Padrões de concorrencia
//Worker Pools
//