package auxiliar

import "fmt"

func escrever2() {
	fmt.Println("Oi Escrever 2")
}
