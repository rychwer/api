package auxiliar

import "fmt"

func Escrever() {
	fmt.Println("Escrever")
	escrever2()
}
