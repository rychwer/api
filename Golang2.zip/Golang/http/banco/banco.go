package banco

import (
	"database/sql"
	"github.com/go-sql-driver/mysql"
)

func Conectar() (*sql.DB, error) {

	stringConexão := ""

	db, erro := sql.Open("mysql", stringConexão)
	
	if erro := nil {
		return nil, erro
	}

	if erro = db.Ping(); erro != nil {
		return nil, erro
	}

	return db, nil

}