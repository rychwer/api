package servidor

import (
	"strconv"
	"github.com/gorilla/mux"
	"fmt"
	"encoding/json"
	"net/http"
	"io/ioutil"
)

type usuario struct {
	ID uint32 `json:"id"`
	Nome string `json:"nome"`
	Email string `json:"email"`
}

func CriarUsuario(w http.ResponseWriter, r *http.Request) {

	corpoRequisicao, erro := ioutil.ReadAll(r.Body)

	if erro != nil {
		w.Write([]byte("Erro 1"))
		return
	}

	var usuario usuario

	if erro = json.Unmarshal(corpoRequisicao, &usuario); erro != nil {
		w.Write([]byte("Erro 2"))
		return
	}

	w.WriteHeader(http.StatusCreated)
	if erro := json.NewEncoder(w).Encode(usuario); erro != nil {
		w.Write([]byte("Erro 3"))
		return
	}
	fmt.Println(usuario)

}

func GetUsuario(w http.ResponseWriter, r *http.Request) {
	parametros := mux.Vars(r)

	ID, erro := strconv.ParseUint(parametros["id"], 10, 32)
	if erro != nil {
		w.Write([]byte("Erro 3"))
	}

	w.WriteHeader(http.StatusOK)
	if erro := json.NewEncoder(w).Encode(ID); erro != nil {
		w.Write([]byte("Erro 4"))
		return
	}

}