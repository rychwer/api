package main

import (
	"http/servidor"
	"fmt"
	"log"
	"net/http"

	"github.com/gorilla/mux"
)

func main() {

	router := mux.NewRouter()
	router.HandleFunc("/home", servidor.CriarUsuario).Methods(http.MethodPost)
	router.HandleFunc("/home/{id}", servidor.GetUsuario).Methods(http.MethodGet)

	fmt.Println("Servidor iniciado na porta 5000")
	log.Fatal(http.ListenAndServe(":5000", router))

}
